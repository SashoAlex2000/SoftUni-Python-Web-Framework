from django.apps import AppConfig


class ToDoAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'practice_to_do_app.to_do_app'
